import { useState } from "react";
import { ChevronDown, Download, MessageCircle, Instagram, Facebook, Twitter, Youtube } from "lucide-react";

interface AccordionItem {
  id: string;
  title: string;
  items?: { label: string; url?: string }[];
}

const accordionItems: AccordionItem[] = [
  {
    id: "institucional",
    title: "Institucional",
    items: [
      { label: "Conheça a UNIASSELVI" },
      { label: "Unidades e polos" },
      { label: "Editora UNIASSELVI" },
      { label: "Blog UNIASSELVI" },
      { label: "Programas de Extensão" },
      { label: "Comissão Própria de Avaliação" },
      { label: "Regulamentos" },
      { label: "Portal do egresso" },
      { label: "Trabalhe na UNIASSELVI" },
      { label: "Seja nosso parceiro" },
      { label: "Seja nosso fornecedor" },
    ],
  },
  {
    id: "comunicacao",
    title: "Comunicação Institucional",
    items: [
      { label: "Canal de Ética" },
      { label: "Ouvidoria" },
      { label: "Publicações legais" },
      { label: "Notícias" },
      { label: "Núcleos de atendimento" },
      { label: "Nossos conteúdos" },
    ],
  },
  {
    id: "cursos",
    title: "Cursos",
    items: [
      { label: "Graduação", url: "https://portal.uniasselvi.com.br/cursos/graduacao" },
      { label: "Pós-Graduação" },
      { label: "Técnicos" },
      { label: "Profissionalizante" },
      { label: "Cursos Livres" },
      { label: "Todos os cursos" },
    ],
  },
  {
    id: "cursos-area",
    title: "Cursos por área de interesse",
    items: [
      { label: "Agrárias e meio ambiente" },
      { label: "Alimentos e Bebidas" },
      { label: "Artes e Design" },
      { label: "Comunicação" },
      { label: "Educação" },
      { label: "Engenharia e Arquitetura" },
      { label: "Gestão e Negócios" },
      { label: "Jurídico e Segurança" },
      { label: "Saúde e Bem-estar" },
      { label: "Tecnologia" },
    ],
  },
  {
    id: "candidato",
    title: "Área do Candidato",
    items: [],
  },
  {
    id: "processos",
    title: "Resultados de Processos Seletivos",
    items: [
      { label: "EAD" },
      { label: "Presencial" },
    ],
  },
  {
    id: "ava",
    title: "Ambiente Virtual do Aluno (AVA)",
    items: [
      { label: "Graduação" },
      { label: "Pós-graduação - Online" },
      { label: "Pós-graduação - Semipresencial" },
      { label: "Técnicos" },
      { label: "Profissionalizantes" },
      { label: "Cursos Livres" },
    ],
  },
  {
    id: "servicos",
    title: "Serviços Acadêmicos",
    items: [
      { label: "Graduação" },
      { label: "Pós-Graduação" },
      { label: "Técnicos" },
      { label: "Profissionalizante" },
    ],
  },
  {
    id: "colaborador",
    title: "Área do colaborador",
    items: [{ label: "Acesse Aqui" }],
  },
];

export default function Footer() {
  const [expandedItems, setExpandedItems] = useState<Record<string, boolean>>({});

  const toggleAccordion = (id: string) => {
    setExpandedItems((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="w-full bg-white border-t border-slate-200">
      {/* FAQ Section */}
      <div className="border-b border-slate-200 px-4 sm:px-6 lg:px-8 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="text-sm font-semibold text-slate-900">
            FAQ - Dúvidas sobre o diploma digital e sua validade
          </div>
          <a
            href="https://portal.uniasselvi.com.br/institucional/diploma-digital?download"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 font-semibold"
          >
            <Download className="w-4 h-4" />
            Download
          </a>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="px-4 sm:px-6 lg:px-8 py-8 shadow-none">
        <div className="max-w-7xl mx-auto shadow-none">
          {/* Contact Section */}
          <div className="flex items-center gap-4 mb-8 pb-8 border-b border-slate-200">
            <img
              src="https://cdn.builder.io/api/v1/image/assets%2F26d9035f3efd477780153e3da945f024%2F8bf5ad01b9b941f299e635292e12a8e0?format=webp&width=150"
              alt="UNIASSELVI"
              className="h-8 w-auto flex-shrink-0"
            />
            <p className="text-slate-900 font-bold text-sm hidden sm:block">UNIASSELVI</p>
            <div className="ml-auto flex items-center gap-3 bg-green-500 rounded-full px-6 py-3">
              <MessageCircle className="w-6 h-6 text-white flex-shrink-0" />
              <div className="text-white">
                <p className="text-xs font-semibold">Contato/WhatsApp</p>
                <a
                  href="https://api.whatsapp.com/send?phone=554733016100"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm font-bold hover:underline transition-all"
                >
                  (47) 3301-6100
                </a>
              </div>
            </div>
          </div>

          {/* Accordion Menu */}
          <div className="space-y-0 mb-8">
            {accordionItems.map((item) => (
              <div key={item.id} className="border-b border-slate-200">
                <button
                  onClick={() => toggleAccordion(item.id)}
                  className="w-full flex items-center justify-between py-4 text-left hover:bg-slate-50 transition-colors"
                >
                  <span className="font-semibold text-slate-900">{item.title}</span>
                  <ChevronDown
                    className={`w-6 h-6 text-slate-600 transition-transform ${
                      expandedItems[item.id] ? "rotate-180" : ""
                    }`}
                  />
                </button>
                {expandedItems[item.id] && item.items && (
                  <div className="pb-4 pl-4 space-y-2">
                    {item.items.map((subitem) => (
                      <div key={subitem.label}>
                        {subitem.url ? (
                          <a
                            href={subitem.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-slate-600 hover:text-blue-600 hover:underline py-1 block transition-colors"
                          >
                            {subitem.label}
                          </a>
                        ) : (
                          <div className="text-sm text-slate-600 py-1">
                            {subitem.label}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* e-MEC Section */}
          <div className="bg-slate-50 rounded-lg p-8 mb-8">
            <p className="text-slate-900 text-sm mb-4">
              Consulte aqui o cadastro da Instituição no Sistema e-MEC
            </p>
            <div className="bg-white border-2 border-blue-500 rounded-lg p-6 inline-block">
              <div className="flex flex-col items-center gap-3">
                <div className="flex items-center justify-center gap-2">
                  <img
                    src="https://cdn.builder.io/api/v1/image/assets%2F26d9035f3efd477780153e3da945f024%2F7da5f1ecce1445cc9433651b5caf7949?format=webp&width=200"
                    alt="e-MEC Logo"
                    className="h-8 w-8 object-contain"
                  />
                  <span className="text-xs font-bold text-blue-600">e-MEC</span>
                </div>
                <img
                  src="https://cdn.builder.io/api/v1/image/assets%2F26d9035f3efd477780153e3da945f024%2Fa5125404bcf24eeaab692df373be0144?format=webp&width=200"
                  alt="e-MEC QR Code"
                  className="w-32 h-32 object-contain"
                />
                <button className="text-blue-600 font-bold text-sm hover:text-blue-700">
                  ACESSE JÁ
                </button>
              </div>
            </div>
          </div>

          {/* Social Media & Copyright */}
          <div className="border-t border-slate-200 pt-8">
            <div className="flex justify-center gap-4 mb-8">
              <a
                href="https://www.instagram.com/uniasselvioficial/"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-slate-900 text-white rounded-full p-3 hover:bg-slate-800 transition-colors"
                aria-label="Instagram"
                title="Instagram"
              >
                <Instagram className="w-6 h-6" />
              </a>
              <a
                href="https://www.facebook.com/uniasselvi/"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-slate-900 text-white rounded-full p-3 hover:bg-slate-800 transition-colors"
                aria-label="Facebook"
                title="Facebook"
              >
                <Facebook className="w-6 h-6" />
              </a>
              <a
                href="https://x.com/uniasselvi"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-slate-900 text-white rounded-full p-3 hover:bg-slate-800 transition-colors"
                aria-label="X (Twitter)"
                title="X (Twitter)"
              >
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24h-6.514l-5.106-6.666-5.852 6.666H2.428l7.723-8.835L.554 2.25h6.696l4.622 6.03 5.344-6.03zM17.534 20.75h1.832L6.455 3.75H4.527l13.007 17z" />
                </svg>
              </a>
              <a
                href="https://www.youtube.com/user/wwwuniasselvi"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-slate-900 text-white rounded-full p-3 hover:bg-slate-800 transition-colors"
                aria-label="YouTube"
                title="YouTube"
              >
                <Youtube className="w-6 h-6" />
              </a>
            </div>
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-slate-600">
              <span>© 2023 - Todos os direitos reservados</span>
              <button
                onClick={scrollToTop}
                className="flex items-center gap-2 hover:text-slate-900 font-semibold transition-colors"
              >
                Voltar ao topo
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
