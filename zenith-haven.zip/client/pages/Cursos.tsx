import Layout from "@/components/Layout";
import { Link } from "react-router-dom";

export default function Cursos() {
  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h1 className="text-4xl font-bold text-slate-900 mb-4">
              Cursos
            </h1>
            <p className="text-lg text-slate-600 mb-8">
              Esta página será preenchida em breve com informações sobre os cursos disponíveis.
            </p>
            <div className="bg-blue-50 rounded-lg p-6 border border-blue-200">
              <p className="text-slate-700 mb-4">
                Para adicionar conteúdo a esta página, continue prompting o assistente de IA.
              </p>
              <Link
                to="/"
                className="inline-block px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
              >
                Voltar à Página Inicial
              </Link>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
