import { useState, useEffect } from "react";
import { Link as RouterLink } from "react-router-dom";
import { Download, FileText } from "lucide-react";
import Layout from "@/components/Layout";

type ValidationState = "empty" | "valid" | "invalid";

interface DiplomaData {
  id: string;
  name: string;
  course: string;
  institution: string;
  year: number;
  status: "active" | "inactive";
  student_code: string;
}

const mockDiplomas: Record<string, DiplomaData> = {
  "1472.1472.b33496cb0044d46ef535108fa4dfef6bce5bfc85c6591d568e34bc0b7e1aafb1": {
    id: "1472.1472.b33496cb0044d46ef535108fa4dfef6bce5bfc85c6591d568e34bc0b7e1aafb1",
    name: "João Silva Santos",
    course: "Engenharia de Computação",
    institution: "Universidade Federal",
    year: 2023,
    status: "active",
    student_code: "1472.1472.b33496cb0044d46ef535108fa4dfef6bce5",
  },
  "1472.1472.b08151cb0044d46ef535108fa4dfef6bce5bfc85c6591d568e34bc0b7e1aafb1": {
    id: "1472.1472.b08151cb0044d46ef535108fa4dfef6bce5bfc85c6591d568e34bc0b7e1aafb1",
    name: "Carlos Roberto Silva",
    course: "Administração de Empresas",
    institution: "Universidade Estadual",
    year: 2024,
    status: "active",
    student_code: "1472.1472.b08151cb0044d46ef535108fa4dfef6bce5",
  },
  "DD123456": {
    id: "DD123456",
    name: "Maria Oliveira Costa",
    course: "Administração de Empresas",
    institution: "Universidade Estadual",
    year: 2024,
    status: "active",
    student_code: "DD123456",
  },
};

export default function Index() {
  const defaultCode = "1472.1472.b08151cb0044d46ef535108fa4dfef6bce5bfc85c6591d568e34bc0b7e1aafb1";
  const [validationCode, setValidationCode] = useState(defaultCode);
  const [validationState, setValidationState] = useState<ValidationState>("valid");
  const [diplomaData, setDiplomaData] = useState<DiplomaData | null>(
    mockDiplomas[defaultCode as keyof typeof mockDiplomas] || null
  );
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    // Load default diploma on mount
    const diploma = mockDiplomas[defaultCode as keyof typeof mockDiplomas];
    if (diploma) {
      setDiplomaData(diploma);
      setValidationState("valid");
    }
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();

    const code = validationCode.trim();

    if (code in mockDiplomas) {
      const diploma = mockDiplomas[code as keyof typeof mockDiplomas];
      setDiplomaData(diploma);
      setValidationState("valid");
    } else {
      setDiplomaData(null);
      setValidationState("invalid");
    }
  };


  return (
    <Layout>
      <div className="bg-white">
        {/* Breadcrumb */}
        <div className="bg-white border-b border-slate-200 px-4 sm:px-6 lg:px-8 py-4">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <span>Uniasselvi</span>
              <span className="text-slate-400">›</span>
              <RouterLink to="/institucional" className="hover:text-slate-900">
                Institucional
              </RouterLink>
              <span className="text-slate-400">›</span>
              <span className="text-slate-900 font-medium">Diploma Digital</span>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Title */}
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-4xl font-bold text-slate-900">Diploma Digital</h1>
            <div className="relative">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="bg-slate-900 text-white rounded-md p-3 hover:bg-slate-800 transition-colors"
              >
                <span className="text-xl font-light">+</span>
              </button>

              {/* Menu Dropdown */}
              {isMenuOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-white border border-slate-300 rounded-lg shadow-lg z-50">
                  {/* Institucional Section */}
                  <div className="border-b border-slate-200">
                    <div className="px-4 py-3 font-semibold text-slate-900 text-sm bg-slate-50">
                      Institucional:
                    </div>
                    <a href="#" onClick={() => setIsMenuOpen(false)} className="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                      Conheça a UNIASSELVI
                    </a>
                    <a href="#" onClick={() => setIsMenuOpen(false)} className="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                      História
                    </a>
                    <a href="#" onClick={() => setIsMenuOpen(false)} className="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                      Unidades e Polos
                    </a>
                    <a href="#" onClick={() => setIsMenuOpen(false)} className="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                      Missão, visão e valores
                    </a>
                    <a href="#" onClick={() => setIsMenuOpen(false)} className="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                      Responsabilidade social
                    </a>
                  </div>

                  {/* Support & Ethics */}
                  <div className="border-b border-slate-200">
                    <a href="#" onClick={() => setIsMenuOpen(false)} className="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                      Canal de Ética
                    </a>
                    <a href="#" onClick={() => setIsMenuOpen(false)} className="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                      Ouvidoria
                    </a>
                  </div>

                  {/* Legal & Policies */}
                  <div className="border-b border-slate-200">
                    <a href="#" onClick={() => setIsMenuOpen(false)} className="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                      Política de Privacidade
                    </a>
                    <a href="#" onClick={() => setIsMenuOpen(false)} className="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                      Publicações legais
                    </a>
                  </div>

                  {/* Career & Partnerships */}
                  <div className="border-b border-slate-200">
                    <a href="#" onClick={() => setIsMenuOpen(false)} className="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                      Trabalhe conosco
                    </a>
                    <a href="#" onClick={() => setIsMenuOpen(false)} className="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                      Seja nosso parceiro
                    </a>
                  </div>

                  {/* Service Centers & Other */}
                  <div>
                    <a href="#" onClick={() => setIsMenuOpen(false)} className="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                      Núcleos de atendimento
                    </a>
                    <a href="#" onClick={() => setIsMenuOpen(false)} className="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                      CPA
                    </a>
                    <a href="#" onClick={() => setIsMenuOpen(false)} className="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                      Portal da Extensão
                    </a>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Search Form */}
          <div className="mb-8">
            <label className="block text-lg font-semibold text-slate-900 mb-3">
              Código de Validação:
            </label>
            <form onSubmit={handleSearch} className="space-y-4">
              <input
                type="text"
                value={validationCode}
                onChange={(e) => setValidationCode(e.target.value)}
                placeholder="Digite o código de validação"
                className="w-full px-4 py-3 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition-all bg-white"
              />

              <div className="flex gap-3 justify-center">
                <button
                  type="submit"
                  style={{
                    backgroundColor: '#fde047',
                    color: '#1f2937'
                  }}
                  className="px-12 py-3 rounded-md hover:opacity-90 transition-all font-bold text-lg"
                >
                  Pesquisar
                </button>
              </div>
            </form>
          </div>

          {/* Valid State */}
          {validationState === "valid" && diplomaData && (
            <div className="space-y-6">
              {/* Success Banner */}
              <div className="bg-green-100 border border-green-300 rounded-md p-4">
                <p className="text-green-800 font-semibold text-center text-lg">
                  Diploma ativo
                </p>
              </div>

              {/* Diploma Details */}
              <div>
                <h2 className="text-2xl font-bold text-slate-900 mb-6">
                  Diploma Digital
                </h2>

                {/* Files Section */}
                <div className="space-y-4 mb-8">
                  <div className="flex items-start gap-4 p-4 border border-slate-300 rounded-md bg-white hover:bg-slate-50 transition-colors">
                    <div className="flex-shrink-0 w-16 h-16 flex items-center justify-center">
                      <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <defs>
                          <filter id="shadow" x="-50%" y="-50%" width="200%" height="200%">
                            <feDropShadow dx="0" dy="2" stdDeviation="3" floodOpacity="0.15" />
                          </filter>
                        </defs>
                        <g filter="url(#shadow)">
                          {/* Document background */}
                          <rect x="8" y="4" width="40" height="48" rx="2" fill="#E5E7EB" />
                          {/* Document fold corner */}
                          <polygon points="48,4 48,16 36,4" fill="#D1D5DB" />
                          {/* Content area */}
                          <rect x="12" y="10" width="32" height="28" fill="white" />
                          {/* Decorative lines */}
                          <line x1="14" y1="20" x2="40" y2="20" stroke="#E5E7EB" strokeWidth="1.5" />
                          <line x1="14" y1="24" x2="40" y2="24" stroke="#E5E7EB" strokeWidth="1.5" />
                          <line x1="14" y1="28" x2="35" y2="28" stroke="#E5E7EB" strokeWidth="1.5" />
                          {/* PDF label - bottom left */}
                          <rect x="8" y="44" width="24" height="12" fill="#EF4444" rx="1" />
                          <text x="20" y="53" fontFamily="Arial, sans-serif" fontSize="8" fontWeight="900" fill="white" textAnchor="middle">PDF</text>
                        </g>
                      </svg>
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-slate-900 break-all text-sm">
                        Arquivo {diplomaData.student_code}
                      </p>
                      <button className="text-blue-600 hover:text-blue-700 font-semibold mt-2 inline-flex items-center gap-2">
                        <Download className="w-4 h-4" />
                        Download
                      </button>
                    </div>
                  </div>

                  <div className="flex items-start gap-4 p-4 border border-slate-300 rounded-md bg-white hover:bg-slate-50 transition-colors">
                    <div className="flex-shrink-0 w-16 h-16 flex items-center justify-center">
                      <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <defs>
                          <filter id="shadow" x="-50%" y="-50%" width="200%" height="200%">
                            <feDropShadow dx="0" dy="2" stdDeviation="3" floodOpacity="0.15" />
                          </filter>
                        </defs>
                        <g filter="url(#shadow)">
                          {/* Document background */}
                          <rect x="8" y="4" width="40" height="48" rx="2" fill="#E5E7EB" />
                          {/* Document fold corner */}
                          <polygon points="48,4 48,16 36,4" fill="#D1D5DB" />
                          {/* Content area */}
                          <rect x="12" y="10" width="32" height="28" fill="white" />
                          {/* Decorative lines */}
                          <line x1="14" y1="20" x2="40" y2="20" stroke="#E5E7EB" strokeWidth="1.5" />
                          <line x1="14" y1="24" x2="40" y2="24" stroke="#E5E7EB" strokeWidth="1.5" />
                          <line x1="14" y1="28" x2="35" y2="28" stroke="#E5E7EB" strokeWidth="1.5" />
                          {/* XML label - bottom left */}
                          <rect x="8" y="44" width="24" height="12" fill="#0EA5E9" rx="1" />
                          <text x="20" y="53" fontFamily="Arial, sans-serif" fontSize="8" fontWeight="900" fill="white" textAnchor="middle">XML</text>
                        </g>
                      </svg>
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-slate-900 break-all text-sm">
                        Arquivo {diplomaData.student_code}
                      </p>
                      <button className="text-blue-600 hover:text-blue-700 font-semibold mt-2 inline-flex items-center gap-2">
                        <Download className="w-4 h-4" />
                        Download
                      </button>
                    </div>
                  </div>
                </div>

                {/* Histórico Escolar Section */}
                <div className="mb-8">
                  <h3 className="text-2xl font-bold text-slate-900 mb-6">
                    Histórico Escolar
                  </h3>
                  <div className="bg-slate-50 rounded-md p-8 text-center text-slate-600">
                    <p>Histórico escolar será exibido aqui quando disponível</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Invalid State */}
          {validationState === "invalid" && (
            <div className="bg-red-50 border border-red-300 rounded-md p-6">
              <h3 className="text-lg font-bold text-red-800 mb-2">
                Código inválido ou não encontrado
              </h3>
              <p className="text-red-700">
                O código de validação digitado não foi encontrado em nossa base de dados.
                Verifique se o código está correto e tente novamente.
              </p>
            </div>
          )}

        </div>
      </div>
    </Layout>
  );
}
